export const site = {
  name: "Raihan Islam Miraj",
  title: "Full Stack Developer · AI SaaS Product Engineer",
  url: "https://www.raihanmiraj.com",
  email: "rsnmiraj@gmail.com",
  location: "Dhaka, Bangladesh",
  description: "Raihan Islam Miraj builds AI-powered SaaS products, multi-tenant platforms, payments, APIs, and polished product experiences.",
  socials: {
    github: "https://github.com/raihanmiraj", linkedin: "https://www.linkedin.com/in/raihan-miraj/",
    youtube: "https://www.youtube.com/@RaihanMiraj", x: "https://x.com/RaihanMiraj",
  },
} as const;
export function absoluteUrl(path = "") { return new URL(path, site.url).toString(); }
export function slugify(value: string) {
  return value.toLowerCase().trim().normalize("NFKD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 100);
}
