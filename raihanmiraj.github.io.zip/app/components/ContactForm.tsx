"use client";
import { useState } from "react";
export default function ContactForm() {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle"); const [error, setError] = useState("");
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setStatus("loading"); setError(""); const form = event.currentTarget; const data = Object.fromEntries(new FormData(form));
    try { const response = await fetch("/api/contacts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }); const result = await response.json(); if (!response.ok) throw new Error(result.error || "Could not send your message."); form.reset(); setStatus("success"); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Could not send your message."); setStatus("error"); }
  }
  return <form className="contact-form" onSubmit={submit}><div className="form-row"><label>Name<input name="name" required minLength={2} maxLength={80}/></label><label>Email<input name="email" type="email" required maxLength={160}/></label></div><label className="honeypot" aria-hidden="true">Website<input name="website" tabIndex={-1} autoComplete="off"/></label><label>Message<textarea name="message" required minLength={20} maxLength={4000} rows={5} placeholder="Tell me about the product, team, or problem you’re working on."/></label><div className="form-action"><button className="button" disabled={status === "loading"}>{status === "loading" ? "Sending…" : "Send message ↗"}</button><p role="status">{status === "success" ? "Thanks — your message is in my inbox." : status === "error" ? error : "Or email me directly at rsnmiraj@gmail.com"}</p></div></form>;
}
