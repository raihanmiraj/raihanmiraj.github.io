"use client";
import Link from "next/link";
import { useState } from "react";
const nav = [["Work", "/projects"], ["Experience", "/#experience"], ["Journal", "/blogs"], ["About", "/about"], ["Contact", "/#contact"]];
export default function Header() {
  const [open, setOpen] = useState(false);
  return <header className="site-header"><a className="skip-link" href="#main">Skip to content</a><div className="container nav-shell">
    <Link className="wordmark" href="/" aria-label="Raihan Miraj, home">RM<span>.</span></Link>
    <button className="menu-button" onClick={() => setOpen(!open)} aria-expanded={open} aria-controls="site-nav">{open ? "Close" : "Menu"}</button>
    <nav id="site-nav" className={open ? "nav-links open" : "nav-links"} aria-label="Primary">
      {nav.map(([label, href]) => <Link key={href} href={href} onClick={() => setOpen(false)}>{label}</Link>)}
      <a className="nav-resume" href="https://drive.google.com/file/d/180EiOBvFXP9YIwERBN43dyxSeGEP4891/view" target="_blank" rel="noreferrer">Resume ↗</a>
      <a className="button small" href="mailto:rsnmiraj@gmail.com">Let&apos;s talk ↗</a>
    </nav>
  </div></header>;
}
