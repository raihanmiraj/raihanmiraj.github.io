import Link from "next/link";
import { site } from "@/lib/site";
export default function Footer() { return <footer className="site-footer"><div className="container footer-inner"><p>© {new Date().getFullYear()} {site.name}<br/><span>{site.location}</span></p><nav aria-label="Social links"><a href={site.socials.github}>GitHub</a><a href={site.socials.linkedin}>LinkedIn</a><a href={site.socials.x}>X</a><Link href="/login">Admin</Link></nav></div></footer>; }
