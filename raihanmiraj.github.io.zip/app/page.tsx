import { HomeView } from "@/components/home/HomeView";
import { getBlogs, getProjects } from "@/lib/data";
export const dynamic = "force-dynamic";
export default async function Home() { const [featured, fallback, blogs] = await Promise.all([getProjects({ featured: true, limit: 6 }), getProjects({ limit: 6 }), getBlogs({ limit: 3 })]); return <HomeView projects={featured.length ? featured : fallback} blogs={blogs}/>; }
