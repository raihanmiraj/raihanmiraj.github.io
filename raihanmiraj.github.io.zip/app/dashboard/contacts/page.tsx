import { getContacts } from "@/lib/data";
import { ContactActions } from "@/components/admin/ContactActions";
type ContactRow={_id:string;name:string;email:string;message:string;read:boolean;createdAt:string};
export const dynamic="force-dynamic";
export default async function ContactsPage(){const items=await getContacts() as ContactRow[];return <><div className="dash-heading"><div><p className="eyebrow">Inbox</p><h1>Contacts</h1></div></div><div className="message-list">{items.map(item=><article className={item.read?"message-card read":"message-card"} key={item._id}><div className="message-head"><div><h2>{item.name}</h2><a href={`mailto:${item.email}`}>{item.email}</a></div><time>{new Intl.DateTimeFormat("en",{dateStyle:"medium"}).format(new Date(item.createdAt))}</time></div><p>{item.message}</p><ContactActions id={item._id} read={item.read}/></article>)}{!items.length?<div className="empty">Your inbox is clear.</div>:null}</div></>}
