import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import ConditionalLayout from "./components/ConditionalLayout";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://www.raihanmiraj.com"),
  title: { default: "Raihan Miraj — AI SaaS Product Engineer", template: "%s — Raihan Miraj" },
  description: "Full Stack Developer building AI-powered SaaS products, multi-tenant systems, payments, APIs, and polished product experiences.",
  alternates: { canonical: "/" },
  openGraph: { type: "website", siteName: "Raihan Miraj", locale: "en_US" },
  twitter: { card: "summary_large_image", creator: "@RaihanMiraj" },
  robots: { index: true, follow: true },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        suppressHydrationWarning
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <ConditionalLayout>
          {children}
        </ConditionalLayout>
      </body>
    </html>
  );
}
